//
//  MRProgressView.h
//  MASClient
//
//  Created by Ludovica Acciai on 24/08/17.
//  Copyright © 2017 Accenture - MAS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MRProgressView : UIProgressView

@end
