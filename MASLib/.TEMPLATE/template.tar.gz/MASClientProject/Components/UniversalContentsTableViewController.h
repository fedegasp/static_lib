//
//  UniversalContentsTableViewController.h
//  MASClient
//
//  Created by Federico Gasperini on 30/01/17.
//  Copyright © 2017 Accenture - MAS. All rights reserved.
//

#import "ContentsTableViewController.h"

@interface UniversalContentsTableViewController : ContentsTableViewController

@end
