//
//  NotificationView.h
//  MASClient
//
//  Created by Gai, Fabio on 21/11/16.
//  Copyright © 2016 Accenture - MAS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NotificationView : UIView
   
@property (weak, nonatomic) IBOutlet UIImageView* imageView;
   
@end
