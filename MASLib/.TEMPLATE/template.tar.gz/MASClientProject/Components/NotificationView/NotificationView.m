//
//  NotificationView.m
//  MASClient
//
//  Created by Gai, Fabio on 21/11/16.
//  Copyright © 2016 Accenture - MAS. All rights reserved.
//

#import "NotificationView.h"

@interface NotificationView ()

@end

@implementation NotificationView

-(void)awakeFromNib
{
   [super awakeFromNib];
}

@end
