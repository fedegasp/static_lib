//
//  MRTitlePageObject.h
//  MASClient
//
//  Created by Enrico Luciano on 28/07/17.
//  Copyright © 2017 Accenture - MAS. All rights reserved.
//


@interface MRTitlePageObject : MRPageObject
@property (strong,nonatomic) IBInspectable  NSString *title;

@end
