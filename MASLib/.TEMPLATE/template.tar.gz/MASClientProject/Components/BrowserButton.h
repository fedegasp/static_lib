//
//  BrowserButton.h
//  MASClient
//
//  Created by Gai, Fabio on 13/12/16.
//  Copyright © 2016 Accenture - MAS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BrowserButton : UIButton
@property IBInspectable NSString *url;
@end
