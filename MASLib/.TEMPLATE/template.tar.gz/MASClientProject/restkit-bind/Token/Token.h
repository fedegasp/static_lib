//
//  Token.h
//  restkit-bind
//
//  Created by Federico Gasperini on 24/07/17.
//  Copyright © 2017 Federico Gasperini. All rights reserved.
//

#import <MRBackEnd/IKRequest.h>

@interface Token : IKRequest

+(instancetype)getToken;

@end
