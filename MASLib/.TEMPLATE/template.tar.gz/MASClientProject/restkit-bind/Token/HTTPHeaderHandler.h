//
//  HTTPHeaderHandler.h
//  dpr
//
//  Created by Federico Gasperini on 15/03/16.
//  Copyright © 2016 Accenture. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HTTPHeaderHandler : NSObject

+(void)setToken:(NSString*)token;

@end
