#ifndef __ALL_HEADERS__
#define __ALL_HEADERS__
@import MobileCoreServices;
@import SystemConfiguration;
#import <MRBackEnd/IKEnvironment.h>
#import <MRRestKit/IKObjectManager.h>
#endif
