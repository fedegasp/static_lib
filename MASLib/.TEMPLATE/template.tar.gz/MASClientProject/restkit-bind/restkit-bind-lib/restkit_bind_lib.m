//
//  restkit_bind_lib.m
//  restkit-bind-lib
//
//  Created by Federico Gasperini on 10/11/15.
//  Copyright © 2015 Federico Gasperini. All rights reserved.
//

#import "restkit_bind_lib.h"

@implementation restkit_bind_lib

@end
