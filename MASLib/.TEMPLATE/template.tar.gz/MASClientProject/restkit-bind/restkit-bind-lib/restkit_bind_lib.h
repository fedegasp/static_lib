//
//  restkit_bind_lib.h
//  restkit-bind-lib
//
//  Created by Federico Gasperini on 10/11/15.
//  Copyright © 2015 Federico Gasperini. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface restkit_bind_lib : NSObject

@end
