//
//  custom-common.h
//  restkit-bind
//
//  Created by Federico Gasperini on 04/04/16.
//  Copyright © 2016 Federico Gasperini. All rights reserved.
//

#ifndef custom_common_h
#define custom_common_h

#import "IKRequest+token.h"

#endif /* custom_common_h */
