//
//  MRCollectionViewScrollManager.h
//  Card
//
//  Created by Gai, Fabio on 11/02/16.
//  Copyright © 2016 Gai, Fabio. All rights reserved.
//

#import "MRCollectionViewAutorepeater.h"

@interface MRCollectionViewScrollManager : MRCollectionViewAutorepeater
@property IBInspectable BOOL isParallax;
@property IBInspectable BOOL fade3DEffect;
@end
