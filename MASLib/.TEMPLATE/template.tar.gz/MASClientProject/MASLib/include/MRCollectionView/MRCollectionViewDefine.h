//
//  MRCollectionViewDefine.h
//  Card
//
//  Created by Gai, Fabio on 11/02/16.
//  Copyright © 2016 Gai, Fabio. All rights reserved.
//

#ifndef MRCollectionViewDefine_h
#define MRCollectionViewDefine_h

#define NULL_CELL_ID @"MRNullCellID"
#define KDefault_itemsPerView 1

#endif /* MRCollectionViewDefine_h */
