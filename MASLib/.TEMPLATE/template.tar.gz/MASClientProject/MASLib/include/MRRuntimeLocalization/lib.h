//
//  lib.h
//  MRRuntimeLocalization
//
//  Created by Federico Gasperini on 21/07/17.
//  Copyright © 2016 Accenture - MAS. All rights reserved.
//

//#ifndef MRRuntimeLocalization_lib_h
//#define MRRuntimeLocalization_lib_h

#import <MRRuntimeLocalization/NSLocale+languageSupport.h>
#import <MRRuntimeLocalization/NSObject+storyboarObjectId.h>

//#endif /* MRRuntimeLocalization_lib_h */
