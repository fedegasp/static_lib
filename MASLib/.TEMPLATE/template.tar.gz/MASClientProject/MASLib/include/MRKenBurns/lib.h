//
//  lib.h
//  MRKenBurns
//
//  Created by Federico Gasperini on 26/10/16.
//  Copyright © 2016 Accenture - MAS. All rights reserved.
//

//#ifndef MRKenBurns_lib_h
//#define MRKenBurns_lib_h

#import <MRKenBurns/MRKenBurns.h>

//#endif /* MRKenBurns_lib_h */
