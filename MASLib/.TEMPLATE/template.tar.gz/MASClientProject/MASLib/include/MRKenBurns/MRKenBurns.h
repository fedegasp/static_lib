//
//  MKenBurns.h
//  Mobily
//
//  Created by Gai, Fabio on 14/10/15.
//  Copyright © 2015 accenture. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MRKenBurns : UIView
@property (nonatomic, strong) IBInspectable NSString *imageName;
@property BOOL firstTime;
@end
