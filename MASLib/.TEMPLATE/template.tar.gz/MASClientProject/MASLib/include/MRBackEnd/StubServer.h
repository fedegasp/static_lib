//
//  WebServer.h
//  TelcoApp
//
//  Created by Administrator on 03/02/14.
//  Copyright (c) 2014 accenture. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MRWebServer/lib.h>

@interface StubServer : WebServer

@end
