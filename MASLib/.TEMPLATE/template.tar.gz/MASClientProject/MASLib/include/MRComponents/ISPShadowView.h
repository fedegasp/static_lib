//
//  ISPShadowView.h
//  MASClient
//
//  Created by Gai, Fabio on 14/11/16.
//  Copyright © 2016 Accenture - MAS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ISPShadowView : UIView

@end
