//
//  GradientButton.h
//  MASClient
//
//  Created by Gai, Fabio on 05/06/2017.
//  Copyright © 2017 Accenture - MAS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GradientButton : UIButton

@end
