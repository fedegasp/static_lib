//
//  NSDictionary+tableViewCellIdentifier.h
//  MASClient
//
//  Created by Enrico Cupellini on 07/09/2017.
//  Copyright © 2017 Accenture - MAS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (tableViewCellIdentifier)

-(NSString*)isp_tableViewCellIdentifier;

@end
