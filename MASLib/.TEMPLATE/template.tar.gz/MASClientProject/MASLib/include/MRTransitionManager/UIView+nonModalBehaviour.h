//
//  UIView+nonModalBehaviour.h
//  dpr
//
//  Created by Federico Gasperini on 03/12/15.
//  Copyright © 2015 Federico Gasperini. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (nonModalBehaviour)
@property (assign) IBInspectable BOOL nonModal; //DEFAULT NO
@end
