//
//  lib.h
//  MRTabController
//
//  Created by Federico Gasperini on 26/10/16.
//  Copyright © 2016 Accenture - MAS. All rights reserved.
//

//#ifndef MRTabController_lib_h
//#define MRTabController_lib_h

#import <MRCollectionView/lib.h>
#import <MRTabController/MRTabViewController.h>
#import <MRTabController/TabContent.h>

//#endif /* MRTabController_lib_h */
