//
//  TabContent.h
//  MRTabController
//
//  Created by Gai, Fabio on 20/10/16.
//  Copyright © 2016 Gai, Fabio. All rights reserved.
//

#import <MRCollectionView/MRCollectionViewContent.h>

@interface TabContent : MRCollectionViewContent
@property (weak, nonatomic) IBOutlet UILabel *label;
@end
