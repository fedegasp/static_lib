//
//  MRTabViewController.h
//  MRTabController
//
//  Created by Gai, Fabio on 20/10/16.
//  Copyright © 2016 Gai, Fabio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MRTabViewController : UIViewController

@end
