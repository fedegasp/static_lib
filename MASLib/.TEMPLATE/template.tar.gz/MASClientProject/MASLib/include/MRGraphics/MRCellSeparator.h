//
//  MRCellSeparator.h
//  MRGraphics
//
//  Created by Federico Gasperini on 26/07/17.
//  Copyright © 2017 Accenture - MAS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MRCellSeparator : UIView

@end
