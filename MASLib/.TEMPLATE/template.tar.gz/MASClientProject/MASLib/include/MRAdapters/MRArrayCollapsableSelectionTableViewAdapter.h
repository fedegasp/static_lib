//
//  MRArrayCollapsableSelectionTableViewAdapter.h
//  a
//
//  Created by Federico Gasperini on 17/02/16.
//  Copyright © 2016 Federico Gasperini. All rights reserved.
//

#import "MRArrayCollapsableTableViewAdapter.h"

@interface MRArrayCollapsableSelectionTableViewAdapter : MRArrayCollapsableTableViewAdapter

@end
