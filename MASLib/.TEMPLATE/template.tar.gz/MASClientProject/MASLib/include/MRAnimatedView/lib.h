//
//  lib.h
//  MRAnimatedView
//
//  Created by Federico Gasperini on 26/10/16.
//  Copyright © 2016 Accenture - MAS. All rights reserved.
//

//#ifndef MRAnimatedView_lib_h
//#define MRAnimatedView_lib_h

#import <MRAnimatedView/MRAnimatingView.h>

//#endif /* MRAnimatedView_lib_h */
