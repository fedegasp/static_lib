//
//  lib.h
//  MRCurrentLocationManager
//
//  Created by Federico Gasperini on 26/10/16.
//  Copyright © 2016 Accenture - MAS. All rights reserved.
//

//#ifndef MRCurrentLocationManager_lib_h
//#define MRCurrentLocationManager_lib_h

@import CoreLocation;
#import <MRCurrentLocationManager/MRCurrentLocationManager.h>

//#endif /* MRCurrentLocationManager_lib_h */
