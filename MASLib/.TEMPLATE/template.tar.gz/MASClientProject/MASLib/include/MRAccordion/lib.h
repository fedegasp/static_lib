//
//  lib.h
//  MRAccordion
//
//  Created by Federico Gasperini on 26/10/16.
//  Copyright © 2016 Accenture - MAS. All rights reserved.
//

//#ifndef MRAccordion_lib_h
//#define MRAccordion_lib_h

#import <MRAccordion/MRAccordionTableViewController.h>

//#endif /* MRAccordion_lib_h */
