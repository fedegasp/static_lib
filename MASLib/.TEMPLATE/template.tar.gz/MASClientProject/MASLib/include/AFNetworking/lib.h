//
//  lib.h>
//  MRRuntimeLocalization
//
//  Created by Federico Gasperini on 21/07/17.
//  Copyright © 2016 Accenture - MAS. All rights reserved.
//

//#ifndef MRRuntimeLocalization_lib_h
//#define MRRuntimeLocalization_lib_h

#import <AFNetworking/AFNetworkActivityConsoleLogger.h>
#import <AFNetworking/AFNetworkActivityLogger.h>
#import <AFNetworking/AFNetworkActivityLoggerProtocol.h>
#import <AFNetworking/AFHTTPSessionManager.h>
#import <AFNetworking/AFNetworking.h>
#import <AFNetworking/AFNetworkReachabilityManager.h>
#import <AFNetworking/AFSecurityPolicy.h>
#import <AFNetworking/AFURLRequestSerialization.h>
#import <AFNetworking/AFURLResponseSerialization.h>
#import <AFNetworking/AFURLSessionManager.h>

//#endif /* MRRuntimeLocalization_lib_h */
