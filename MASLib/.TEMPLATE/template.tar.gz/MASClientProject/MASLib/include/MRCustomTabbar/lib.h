//
//  lib.h
//  MRCustomTabbar
//
//  Created by Federico Gasperini on 26/10/16.
//  Copyright © 2016 Accenture - MAS. All rights reserved.
//

//#ifndef MRCustomTabbar_lib_h
//#define MRCustomTabbar_lib_h

#import <MRCustomTabbar/MRAbstractCustomTabbarController.h>
#import <MRCustomTabbar/MRConfigurableTabbarController.h>
#import <MRCustomTabbar/MRSegueTabbarController.h>
#import <MRCustomTabbar/MRTabbarConfiguration.h>
#import <MRCustomTabbar/MRTabbarSegue.h>

//#endif /* MRCustomTabbar_lib_h */
