//
//  IKTabbarSegue.h
//  CustomContainer
//
//  Created by Federico Gasperini on 20/04/16.
//  Copyright © 2016 Accenture. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MRTabbarSegue : UIStoryboardSegue

@end
