//
//  lib.h
//  MRSeatManager
//
//  Created by Federico Gasperini on 26/10/16.
//  Copyright © 2016 Accenture - MAS. All rights reserved.
//

//#ifndef MRSeatManager_lib_h
//#define MRSeatManager_lib_h

#import <MRSeatManager/MRSeatManager.h>
#import <MRSeatManager/MRSeatButton.h>

//#endif /* MRSeatManager_lib_h */
