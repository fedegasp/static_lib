//
//  SeatButton.h
//  Seating
//
//  Created by Gai, Fabio on 08/07/16.
//  Copyright © 2016 Gai, Fabio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MRSeatButton : UIButton
@property IBInspectable NSString *seatCode;
@end
