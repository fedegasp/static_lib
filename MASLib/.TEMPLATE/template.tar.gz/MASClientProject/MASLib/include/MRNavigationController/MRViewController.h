//
//
//  Created by fabio on 01/08/15.
//  Copyright (c) 2015 fabio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MRViewController : UIViewController

@property IBInspectable BOOL disableHideKeyboardOnTap;

@end
