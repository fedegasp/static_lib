//
//  lib.h
//  MRPaginationController
//
//  Created by Federico Gasperini on 26/10/16.
//  Copyright © 2016 Accenture - MAS. All rights reserved.
//

//#ifndef MRPaginationController_lib_h
//#define MRPaginationController_lib_h

#import <MRPaginationController/MRPageObject.h>
#import <MRPaginationController/MRPaginationController.h>

//#endif /* MRPaginationController_lib_h */
