//
//  lib.h
//  MRBadgeView
//
//  Created by Federico Gasperini on 26/10/16.
//  Copyright © 2016 Accenture - MAS. All rights reserved.
//

//#ifndef MRBadgeView_lib_h
//#define MRBadgeView_lib_h

#import <MRBadgeView/MRBadgeCounter.h>
#import <MRBadgeView/MRBadgeView.h>

//#endif /* MRBadgeView_lib_h */
