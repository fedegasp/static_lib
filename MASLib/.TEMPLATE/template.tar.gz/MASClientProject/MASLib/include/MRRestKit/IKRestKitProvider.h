//
//  IKRestKitProvider.h
//  iconick-lib
//
//  Created by Federico Gasperini on 16/09/15.
//  Copyright (c) 2015 accenture. All rights reserved.
//

#import <MRBackEnd/BackEndInterface.h>

extern NSString* IKRestKitProviderKey;

@interface IKRestKitProvider : BackEndProvider

@end
