//
//  MASLibVersion.h
//  MASLib
//
//  Created by Federico Gasperini on 04/12/17.
//  Copyright © 2017 Accenture - MAS. All rights reserved.
//

@import Foundation;

@interface MASLib : NSObject

@property (class, readonly, nonnull) NSString* version;

@end
